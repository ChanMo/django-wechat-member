#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class MemberConfig(AppConfig):
    name = u'member'
    verbose_name = u'会员'
