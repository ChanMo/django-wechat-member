#!/usr/bin/python
# vim: set fileencoding=utf-8 :
from django.apps import AppConfig

class WechatMemberConfig(AppConfig):
    name = u'wechat_member'
    verbose_name = u'微信会员'
