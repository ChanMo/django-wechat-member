default_app_config = 'wechat_member.apps.WechatMemberConfig'
